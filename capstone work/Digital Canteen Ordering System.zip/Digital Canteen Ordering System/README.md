# Canteen Cart

Live deployment: https://canteen-cart-bay.vercel.app

The deployment uses a Vercel Node serverless API (`api/index.js`), Neon Postgres, and a static frontend (`public/`). The original C/SQLite starter remains in `src/` as course material. Vercel cannot run its Windows socket server. The deployed backend is JavaScript, not C.

## Demo access

| Role | Username | Password |
|---|---|---|
| Customer | `user123` | `needfood123` |
| Shopkeeper | `owner123` | `orderdone123` |

The customer begins with a ₹50,000 demo wallet. These public example credentials must be replaced before real use. No real payment is processed.

## Deployment

The Vercel project is `resolve18/canteen-cart`. The Neon project is `canteen-cart` in Singapore. `DATABASE_URL` is stored as a secret in Vercel's Production environment. No database credential is committed to source.

The production alias above responds publicly without Vercel sign-in. Vercel still reports authentication protection on the individual deployment URL. The alias and API were checked without Vercel credentials.

## Local development

1. Install Node.js 20 or newer and run `npm install`.
2. Put a Neon Postgres connection string in a local, ignored `.env.local` file as `DATABASE_URL=...`.
3. Run `vercel dev` to serve the static app and API together.

The API creates its schema and inserts demo users and 50 menu items on first use. Passwords use salted scrypt hashes. Login issues a random 20-day session token in an HttpOnly, Secure cookie; only its hash is stored in Postgres. The API enforces roles and performs wallet deduction, order creation, and order item snapshots in one SQL statement.

## API

`POST /api/login`, `POST /api/logout`, `GET /api/me`, `GET /api/menu`, `POST /api/menu`, `PUT /api/menu/:id`, `DELETE /api/menu/:id`, `POST /api/checkout`, `GET /api/orders/mine`, `GET /api/orders`, and `PATCH /api/orders/:id/status`.

Checkout expects `{ "items": [{ "menuItemId": 1, "quantity": 2 }] }` and an optional `Idempotency-Key` header. The server recalculates prices and checks availability and wallet balance.

## C starter

`src/main.c` and `src/db.c` are the original unfinished C/SQLite scaffold supplied with this project. They are not part of the deployed application.

