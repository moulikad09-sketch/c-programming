import { neon } from '@neondatabase/serverless';
import { randomBytes, createHash, scryptSync, timingSafeEqual } from 'node:crypto';

const sql = neon(process.env.DATABASE_URL || process.env.POSTGRES_URL || '');
const hash = s => createHash('sha256').update(s).digest('hex');
const pwd = (s, salt) => scryptSync(s, salt, 64).toString('hex');
const menu = [
['Veg Biryani','Meals',140,1],['Chicken Biryani','Meals',190,0],['Paneer Butter Masala with Roti','Meals',165,1],['Masala Dosa','Meals',85,1],['Idli Sambar (3 pcs)','Meals',55,1],['Medu Vada (2 pcs)','Meals',60,1],['Curd Rice','Meals',70,1],['Sambar Rice','Meals',75,1],['Lemon Rice','Meals',65,1],['Veg Fried Rice','Meals',120,1],['Egg Fried Rice','Meals',130,0],['Chapati Kurma','Meals',95,1],['Veg Thali','Meals',150,1],['Chicken Curry Meal','Meals',210,0],['Rava Upma','Meals',44,1],
['Samosa (2 pcs)','Snacks',30,1],['Veg Puff','Snacks',25,1],['Vada Pav','Snacks',35,1],['French Fries','Snacks',80,1],['Veg Sandwich','Snacks',50,1],['Grilled Cheese Sandwich','Snacks',90,1],['Veg Burger','Snacks',100,1],['Chicken Burger','Snacks',125,0],['Masala Maggi','Snacks',58,1],['Pav Bhaji','Snacks',110,1],['Bread Omelette','Snacks',48,0],['Paneer Roll','Snacks',105,1],['Chicken Roll','Snacks',115,0],['Mini Pizza','Snacks',135,1],['Bhel Puri','Snacks',40,1],
['Filter Coffee','Drinks',20,1],['Masala Chai','Drinks',15,1],['Cold Coffee','Drinks',68,1],['Fresh Lime Soda','Drinks',38,1],['Mango Lassi','Drinks',72,1],['Buttermilk','Drinks',18,1],['Watermelon Juice','Drinks',52,1],['Orange Juice','Drinks',62,1],['Banana Shake','Drinks',78,1],['Chocolate Milkshake','Drinks',88,1],['Bottled Water','Drinks',10,1],['Tender Coconut','Drinks',42,1],
['Gulab Jamun (2 pcs)','Desserts',45,1],['Chocolate Brownie','Desserts',99,1],['Vanilla Ice Cream Cup','Desserts',56,1],['Rasmalai','Desserts',82,1],['Fruit Salad','Desserts',66,1],['Kesari Bath','Desserts',34,1],['Chocolate Cake Slice','Desserts',92,1],['Payasam','Desserts',54,1]
];
let initialized;
async function init() {
  if (!initialized) initialized = (async () => {
    await sql`CREATE TABLE IF NOT EXISTS users(id bigserial PRIMARY KEY, username text UNIQUE NOT NULL, password_hash text NOT NULL, salt text NOT NULL, role text NOT NULL CHECK(role IN ('user','shopkeeper')), display_name text NOT NULL, wallet_balance integer NOT NULL DEFAULT 0)`;
    await sql`CREATE TABLE IF NOT EXISTS sessions(token_hash text PRIMARY KEY, user_id bigint NOT NULL REFERENCES users(id), expires_at timestamptz NOT NULL)`;
    await sql`CREATE TABLE IF NOT EXISTS menu_items(id bigserial PRIMARY KEY, name text NOT NULL, category text NOT NULL, price integer NOT NULL CHECK(price>=0), is_veg boolean NOT NULL, image text, available boolean NOT NULL DEFAULT true)`;
    await sql`CREATE TABLE IF NOT EXISTS orders(id bigserial PRIMARY KEY, bill_number text UNIQUE, user_id bigint NOT NULL REFERENCES users(id), total integer NOT NULL, payment_method text NOT NULL DEFAULT 'Wallet', status text NOT NULL DEFAULT 'Pending', created_at timestamptz NOT NULL DEFAULT now(), finished_at timestamptz, idempotency_key text UNIQUE)`;
    await sql`CREATE TABLE IF NOT EXISTS order_items(id bigserial PRIMARY KEY, order_id bigint NOT NULL REFERENCES orders(id), menu_item_id bigint, name_snapshot text NOT NULL, unit_price_snapshot integer NOT NULL, quantity integer NOT NULL)`;
    for (const [username, password, role, display, wallet] of [['owner123','orderdone123','shopkeeper','Canteen owner',0],['user123','needfood123','user','Canteen guest',50000]]) {
      const salt = randomBytes(16).toString('hex');
      await sql`INSERT INTO users(username,password_hash,salt,role,display_name,wallet_balance) VALUES(${username},${pwd(password,salt)},${salt},${role},${display},${wallet}) ON CONFLICT(username) DO NOTHING`;
    }
    const count = await sql`SELECT count(*)::int AS n FROM menu_items`;
    if (count[0].n === 0) for (const [name, category, price, veg] of menu) await sql`INSERT INTO menu_items(name,category,price,is_veg) VALUES(${name},${category},${price},${!!veg})`;
  })().catch(e => { initialized = null; throw e; });
  return initialized;
}
function send(res, code, data, headers={}) { res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}); res.end(JSON.stringify(data)); }
async function body(req) { let s=''; for await(const c of req){s+=c;if(s.length>50000) throw new Error('Request too large');} return s ? JSON.parse(s) : {}; }
function cookie(req) { return (req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('session='))?.slice(8); }
async function current(req) { const token=cookie(req); if(!token) return null; const rows=await sql`SELECT u.id,u.username,u.role,u.display_name,u.wallet_balance FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=${hash(token)} AND s.expires_at>now()`; return rows[0]||null; }
const safeUser = u => ({id:u.id,username:u.username,role:u.role,displayName:u.display_name,walletBalance:u.wallet_balance});
const validItem = x => x && typeof x.name==='string' && x.name.trim().length>0 && x.name.length<=100 && ['Meals','Snacks','Drinks','Desserts'].includes(x.category) && Number.isInteger(Number(x.price)) && Number(x.price)>=0 && Number(x.price)<=100000 && typeof x.isVeg==='boolean';
async function ordersFor(user, status) {
  const orders = user.role==='shopkeeper' ? await sql`SELECT o.*,u.display_name AS customer FROM orders o JOIN users u ON u.id=o.user_id WHERE (${status||''}='' OR o.status=${status||''}) ORDER BY o.created_at DESC` : await sql`SELECT o.*,u.display_name AS customer FROM orders o JOIN users u ON u.id=o.user_id WHERE o.user_id=${user.id} ORDER BY o.created_at DESC`;
  if(!orders.length) return [];
  const ids=orders.map(x=>Number(x.id)); const lines=await sql`SELECT * FROM order_items WHERE order_id=ANY(${ids}) ORDER BY id`;
  return orders.map(o=>({id:o.id,billNumber:o.bill_number,customer:o.customer,total:o.total,status:o.status,createdAt:o.created_at,items:lines.filter(x=>x.order_id===o.id).map(x=>({name:x.name_snapshot,price:x.unit_price_snapshot,quantity:x.quantity}))}));
}
export default async function handler(req,res) {
  try {
    if(!process.env.DATABASE_URL && !process.env.POSTGRES_URL) return send(res,503,{error:'Database connection is not configured'});
    await init();
    const url=new URL(req.url,'http://localhost'); const path=url.pathname; const method=req.method;
    if(path==='/api/health') { await sql`SELECT 1`; return send(res,200,{status:'ok',database:'connected'}); }
    if(path==='/api/login' && method==='POST') {
      const x=await body(req); if(typeof x.username!=='string'||typeof x.password!=='string'||x.username.length>100||x.password.length>200) return send(res,400,{error:'Enter a valid username and password'});
      const rows=await sql`SELECT * FROM users WHERE username=${x.username}`; const u=rows[0]; const candidate=pwd(x.password,u?.salt||'0'.repeat(32));
      if(!u||!timingSafeEqual(Buffer.from(candidate,'hex'),Buffer.from(u.password_hash,'hex'))) return send(res,401,{error:'Invalid username or password'});
      const token=randomBytes(32).toString('hex'); await sql`INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(${hash(token)},${u.id},now()+interval '20 days')`;
      return send(res,200,{user:safeUser(u)},{'Set-Cookie':`session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=1728000`});
    }
    if(path==='/api/logout' && method==='POST') { const t=cookie(req); if(t) await sql`DELETE FROM sessions WHERE token_hash=${hash(t)}`; return send(res,200,{ok:true},{'Set-Cookie':'session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0'}); }
    const user=await current(req);
    if(path==='/api/me') return user?send(res,200,{user:safeUser(user)}):send(res,401,{error:'Please log in'});
    if(!user) return send(res,401,{error:'Please log in'});
    if(path==='/api/menu' && method==='GET') { const q=(url.searchParams.get('q')||'').slice(0,100); const category=url.searchParams.get('category')||''; const rows=await sql`SELECT id,name,category,price,is_veg AS "isVeg",image,available FROM menu_items WHERE name ILIKE ${'%'+q+'%'} AND (${category}='' OR category=${category}) ORDER BY id`; return send(res,200,{items:rows}); }
    if(path==='/api/menu' && method==='POST') { if(user.role!=='shopkeeper') return send(res,403,{error:'Shopkeeper only'}); const x=await body(req); if(!validItem(x)) return send(res,400,{error:'Enter valid item details'}); const rows=await sql`INSERT INTO menu_items(name,category,price,is_veg,image) VALUES(${x.name.trim()},${x.category},${Number(x.price)},${x.isVeg},${typeof x.image==='string'?x.image.slice(0,500):null}) RETURNING id`; return send(res,201,{id:rows[0].id}); }
    const menuId=path.match(/^\/api\/menu\/(\d+)$/);
    if(menuId && ['PUT','DELETE'].includes(method)) { if(user.role!=='shopkeeper') return send(res,403,{error:'Shopkeeper only'}); const id=Number(menuId[1]); if(method==='DELETE'){const r=await sql`DELETE FROM menu_items WHERE id=${id} RETURNING id`;return send(res,r.length?200:404,{ok:!!r.length});} const x=await body(req); if(x.available!==undefined && Object.keys(x).length===1){if(typeof x.available!=='boolean') return send(res,400,{error:'Invalid availability'});const r=await sql`UPDATE menu_items SET available=${x.available} WHERE id=${id} RETURNING id`;return send(res,r.length?200:404,{ok:!!r.length});} if(!validItem(x)) return send(res,400,{error:'Enter valid item details'}); const r=await sql`UPDATE menu_items SET name=${x.name.trim()},category=${x.category},price=${Number(x.price)},is_veg=${x.isVeg},image=${typeof x.image==='string'?x.image.slice(0,500):null},available=${x.available!==false} WHERE id=${id} RETURNING id`;return send(res,r.length?200:404,{ok:!!r.length}); }
    if(path==='/api/checkout'&&method==='POST') { if(user.role!=='user') return send(res,403,{error:'Customer only'}); const x=await body(req); const items=x.items; if(!Array.isArray(items)||!items.length||items.length>50||items.some(i=>!Number.isInteger(i.menuItemId)||!Number.isInteger(i.quantity)||i.quantity<1||i.quantity>50)) return send(res,400,{error:'Cart contains invalid items or quantities'}); const ids=items.map(i=>i.menuItemId); if(new Set(ids).size!==ids.length) return send(res,400,{error:'Duplicate cart item'}); const key=(req.headers['idempotency-key']||'').toString(); if(key.length>100) return send(res,400,{error:'Invalid idempotency key'}); if(key){const prior=await sql`SELECT id FROM orders WHERE idempotency_key=${key}`;if(prior.length)return send(res,409,{error:'Order already placed'});} const listed=await sql`SELECT id,name,price,available FROM menu_items WHERE id=ANY(${ids})`; if(listed.length!==ids.length||listed.some(i=>!i.available)) return send(res,400,{error:'An item is unavailable. Refresh your cart.'}); const lines=items.map(i=>({...i,...listed.find(v=>Number(v.id)===i.menuItemId)})); const total=lines.reduce((s,i)=>s+i.price*i.quantity,0); const bill='BILL-'+Date.now()+'-'+randomBytes(3).toString('hex'); const snapshot=JSON.stringify(lines.map(i=>({menu_item_id:i.menuItemId,name:i.name,price:i.price,quantity:i.quantity}))); const r=await sql`WITH debit AS (UPDATE users SET wallet_balance=wallet_balance-${total} WHERE id=${user.id} AND wallet_balance>=${total} RETURNING id), placed AS (INSERT INTO orders(bill_number,user_id,total,idempotency_key) SELECT ${bill},id,${total},${key||null} FROM debit RETURNING id) INSERT INTO order_items(order_id,menu_item_id,name_snapshot,unit_price_snapshot,quantity) SELECT placed.id, x.menu_item_id, x.name, x.price, x.quantity FROM placed, jsonb_to_recordset(${snapshot}::jsonb) AS x(menu_item_id bigint,name text,price integer,quantity integer) RETURNING order_id`; if(!r.length) return send(res,400,{error:'Insufficient wallet balance'}); return send(res,201,{billNumber:bill,total}); }
    if(path==='/api/orders/mine'&&method==='GET') { if(user.role!=='user')return send(res,403,{error:'Customer only'});return send(res,200,{orders:await ordersFor(user)}); }
    if(path==='/api/orders'&&method==='GET') { if(user.role!=='shopkeeper')return send(res,403,{error:'Shopkeeper only'});return send(res,200,{orders:await ordersFor(user,url.searchParams.get('status'))}); }
    const statusId=path.match(/^\/api\/orders\/(\d+)\/status$/); if(statusId&&method==='PATCH') {if(user.role!=='shopkeeper')return send(res,403,{error:'Shopkeeper only'});const x=await body(req);if(!['Pending','Finished'].includes(x.status))return send(res,400,{error:'Invalid status'});const r=await sql`UPDATE orders SET status=${x.status},finished_at=${x.status==='Finished'?new Date():null} WHERE id=${Number(statusId[1])} RETURNING id`;return send(res,r.length?200:404,{ok:!!r.length});}
    return send(res,404,{error:'Not found'});
  } catch(e) { console.error(e); return send(res,500,{error:'Server error. Please try again.'}); }
}
