// Minimal stub for Mongoose library – not a real HTTP server.
// The real server is implemented manually in src/main.c.
// This file exists only so the Makefile can compile without errors.

