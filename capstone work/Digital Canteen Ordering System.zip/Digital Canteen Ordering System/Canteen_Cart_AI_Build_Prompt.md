# PROMPT: Build "Canteen Cart", a two-role ordering web app with a C backend

> **Assumptions made (edit if wrong):**
> - Currency is **₹50,000** wallet balance for the user.
> - The app is a **canteen/food ordering system**. The attached reference screenshot is a fashion app, so only its **visual style and layout** are borrowed.

---

## 1. Your role and goal

You are a senior full-stack developer who is strong in **C**. Build a working, responsive web application called **Canteen Cart** for a **C programming course project**. The backend must be written in **C**, the data must live in a **database**, and the frontend must follow the visual reference described in Section 3.

Deliver a working system, not a mock-up. Every button must do something. Do not add features outside this brief (no real payments, delivery, reviews or notifications).

## 2. Roles and core behavior

There are two roles. Role permissions must be enforced **on the server**, not only by hiding buttons.

### 2.1 User (customer)
- Logs in with the user credentials in Section 6.
- Starts with a wallet balance of **₹50,000**.
- Can browse the menu, search and filter by category, and add any available items to the cart in any quantity, as long as the total stays within the wallet balance.
- Proceeds to checkout. On success, the total is deducted from the wallet, a **bill** is generated, and the order goes to the shopkeeper with status **Pending**.
- Can view **My Orders** with each bill's details and status (**Pending** or **Finished**).
- Cannot access any shopkeeper screen or API.

### 2.2 Shopkeeper
- Logs in with the shopkeeper credentials in Section 6.
- **Menu management:** add, edit and delete items, and toggle availability (Available / Out of stock). Each item has a name, category, price, veg/non-veg flag and optional image.
- **Orders and bills:** sees every incoming order as a generated bill (bill number, customer name, time, line items, quantities, unit prices, total, payment method "Wallet").
- Marks each order **Finished** or **Pending**. Allow toggling back from Finished to Pending to correct mistakes.
- Cannot spend wallet money or place orders.

## 3. UI and visual design (follow the attached reference)

The reference shows three mobile screens: an onboarding hero, a home/discover screen, and a cart screen. Recreate **this look and layout**, adapted to food.

### Overall style
- Clean, minimal, modern, premium. Soft off-white page background (about `#F5F5F3`), pure white rounded cards, **solid black** primary buttons and active states, light-gray secondary text.
- Large corner radii (about 16–28px on cards, fully pill-shaped buttons and chips). Very light shadows only.
- Typography: a **serif display font** (e.g. Playfair Display) for big headings such as "Discover" and a clean geometric sans-serif (e.g. Inter or Plus Jakarta Sans) for everything else. The heading uses two lines: the first in black, the second in gray.
- Mobile-first, with a polished layout on tablet and desktop (see Section 8).

### Login / onboarding screen (like the left phone)
- Full-bleed food photograph, or a tasteful placeholder, with a frosted-glass blurred panel on part of the image.
- Large bold white headline, for example "Order ahead. Skip the queue."
- Username and password fields on a glass or white card, and a round black arrow or "Login" button.
- Small pagination dots are optional. Show a clear error on invalid login.

### User home screen (like the middle phone)
- Top row: a round avatar, a small grid/menu icon button, and a bell icon button on the right. Show the **wallet balance** as a small pill ("₹50,000").
- Heading: serif **"Discover"** in black, with **"Your Best Meals"** in gray below.
- Rounded search bar with a magnifier icon (placeholder "Search meals, snacks or drinks"), plus a round filter button at its right. Do not fake an AI feature.
- Horizontally scrollable chips: **All, Meals, Snacks, Drinks, Desserts**. The active chip is a black pill with white text and the others are white pills.
- A **two-column grid** of product cards. Each card has a rounded white image tile, a heart (Favorite) icon at the top right, a **round black "add to cart" button overlapping the bottom center of the image**, and the item name and price centered underneath. Out-of-stock items show a clear "Out of stock" label and a disabled add button.
- **Floating bottom navigation** (white, rounded, slightly elevated): Home, Search, Favorites, Account, with a round black central action button for the Cart that shows an item-count badge.

### Cart screen (like the right phone)
- Back arrow button at the top left and a centered title "My cart".
- Each cart item is a white card with a thumbnail, name, a gray subtitle (category), a small gray category pill, the price at the right, a three-dot menu, a trash icon, and a **round − / quantity / + stepper**. "Add to wishlist" becomes "Add to favorites".
- An **Order Summary** card: Subtotal, a line "No extra charges", and **Total**. Below it show "Wallet balance ₹X" and "Balance after order ₹Y". If the total exceeds the balance, show a muted red message and disable checkout.
- A full-width black pill **"Checkout"** button.

### Shopkeeper screens (same design language)
- **Orders:** the "Orders" heading, summary counts, tabs (All / Pending / Finished), and bill cards. Each bill card has a black "Mark finished" or outlined "Mark pending" pill button, and tapping it expands to the full bill.
- **Menu manager:** a list or grid with an Add item button (black pill), a form in a bottom sheet or modal, edit/delete icons, and an availability switch.

### Palette tokens

| Token | Color | Use |
|---|---|---|
| Black | `#111111` | Primary buttons, active chips, headings |
| Off-white | `#F5F5F3` | Page background |
| White | `#FFFFFF` | Cards and surfaces |
| Gray text | `#8A8A86` | Secondary text |
| Border | `#E8E8E4` | Dividers and card borders |
| Muted red | `#A33E35` | Errors, out-of-stock |
| Muted green | `#2F6B4F` | Finished badge |
| Amber | `#A96A16` | Pending badge |

Never rely on color alone for status: always include a text label or icon.

## 4. Backend architecture (C)

### Stack
- **Language:** C (C11) built with a `Makefile` (gcc).
- **HTTP server:** an embedded C library such as **Mongoose** or **libmicrohttpd**. The C server serves the static frontend files and a JSON REST API.
- **Database:** **SQLite** through its C API, with all queries parameterized (prepared statements).
- **JSON:** cJSON (or similar).
- **Password hashing:** **libsodium** (`crypto_pwhash_str`) or another salted, slow hash. Never store plaintext passwords.

### Suggested project layout
```
canteen-cart/
├── Makefile
├── README.md
├── src/
│   ├── main.c          // start server, init DB, route registration
│   ├── router.c/.h     // maps URL + method to handlers
│   ├── db.c/.h         // open DB, schema creation, transactions
│   ├── auth.c/.h       // login, logout, password verify
│   ├── session.c/.h    // create/validate/delete 20-day sessions
│   ├── menu.c/.h       // menu CRUD, search, availability
│   ├── order.c/.h      // checkout, bills, status updates
│   ├── wallet.c/.h     // balance read/deduct
│   ├── seed.c/.h       // seed users and the 50 menu items
│   └── util.c/.h       // JSON helpers, validation, time, random tokens
├── web/
│   ├── index.html / login.html / cart.html / orders.html ...
│   ├── css/styles.css
│   └── js/ (api.js, menu.js, cart.js, staff.js)
└── data/canteen.db
```

### Database schema
```sql
users(id INTEGER PK, username TEXT UNIQUE, password_hash TEXT,
      role TEXT CHECK(role IN ('user','shopkeeper')),
      display_name TEXT, wallet_balance REAL DEFAULT 0);

sessions(id INTEGER PK, token_hash TEXT UNIQUE, user_id INTEGER REFERENCES users(id),
         created_at INTEGER, expires_at INTEGER);

menu_items(id INTEGER PK, name TEXT, category TEXT, price REAL CHECK(price >= 0),
           is_veg INTEGER, image TEXT, available INTEGER DEFAULT 1);

orders(id INTEGER PK, bill_number TEXT UNIQUE, user_id INTEGER REFERENCES users(id),
       total REAL, payment_method TEXT DEFAULT 'Wallet',
       status TEXT CHECK(status IN ('Pending','Finished')) DEFAULT 'Pending',
       created_at INTEGER, finished_at INTEGER);

order_items(id INTEGER PK, order_id INTEGER REFERENCES orders(id),
            menu_item_id INTEGER, name_snapshot TEXT, unit_price_snapshot REAL,
            quantity INTEGER CHECK(quantity > 0));
```

### REST API

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/login` | public | Verify credentials, create session, set cookie |
| POST | `/api/logout` | any | Delete session, clear cookie |
| GET | `/api/me` | any | Current user, role and wallet balance (used to restore login on page load) |
| GET | `/api/menu` | any | Menu list (supports `?q=` and `?category=`) |
| POST | `/api/menu` | shopkeeper | Add item |
| PUT | `/api/menu/:id` | shopkeeper | Edit item or toggle availability |
| DELETE | `/api/menu/:id` | shopkeeper | Delete item |
| POST | `/api/checkout` | user | Place order from cart (see Section 5) |
| GET | `/api/orders/mine` | user | The user's own orders and bills |
| GET | `/api/orders` | shopkeeper | All orders (supports `?status=`) |
| PATCH | `/api/orders/:id/status` | shopkeeper | Set Pending or Finished |

## 5. Business rules (enforce in C, never trust the client)

- The cart lives in the browser. At checkout the client sends only `[{menuItemId, quantity}]`. The server recalculates everything from database prices.
- Quantities must be integers greater than 0 (set a sensible upper limit per line, such as 50).
- Items must exist and be available. If any are unavailable, reject the order and tell the user which items to remove.
- Checkout must be a **single database transaction** (`BEGIN IMMEDIATE ... COMMIT`) that:
  1. checks the total against the wallet balance,
  2. deducts the balance,
  3. inserts the order and its line items with **name and price snapshots**,
  4. generates a unique bill number (e.g. `BILL-000123`),
  5. rolls back completely on any failure.
- Reject if the balance is insufficient. The wallet must never go negative.
- Prevent duplicate submissions: disable the button in the UI, and have the server reject an identical checkout made in the same moment (for example with a client-generated idempotency key).
- Menu price edits must not change existing orders.
- Shopkeeper-only and user-only endpoints return **403** for the wrong role and **401** when not logged in.
- Validate all input lengths and types, and never build SQL by string concatenation.

## 6. Authentication and 20-day login persistence

### Seed accounts
Create on first run, hashed, never stored in plaintext:

| Role | Username | Password | Starting wallet |
|---|---|---|---|
| Shopkeeper | `owner123` | `orderdone123` | n/a |
| User | `user123` | `needfood123` | ₹50,000 |

Note in the README that these are demo credentials and must be changed for any real use.

### Persistent session requirements
- On successful login, generate a cryptographically random token (32 bytes), store only its **hash** in the `sessions` table with `expires_at = now + 20 days`, and send the raw token in a cookie.
- Cookie settings: `HttpOnly`, `SameSite=Lax`, `Path=/`, `Max-Age=1728000` (20 days), plus `Secure` when served over HTTPS.
- The user must stay logged in across page refreshes, browser restarts and server restarts for **20 days**, because the session is stored in the database and not in memory.
- On every request, the server validates the token against the database and checks that it has not expired. When a session has expired, delete it and require login again.
- Logout deletes the session row and clears the cookie.
- On page load, the frontend calls `/api/me`. If it returns the current user, skip the login page and go to the correct home screen for that role.
- Add basic protection against brute-force login (for example, a short delay or a limit after repeated failures).

## 7. Menu seed data: 50 items with unique prices (₹)

All 50 prices are distinct. Seed these into `menu_items`, with all items available by default.

| # | Item | Category | Price | Veg |
|---|---|---|---|---|
| 1 | Veg Biryani | Meals | 140 | Yes |
| 2 | Chicken Biryani | Meals | 190 | No |
| 3 | Paneer Butter Masala with Roti | Meals | 165 | Yes |
| 4 | Masala Dosa | Meals | 85 | Yes |
| 5 | Idli Sambar (3 pcs) | Meals | 55 | Yes |
| 6 | Medu Vada (2 pcs) | Meals | 60 | Yes |
| 7 | Curd Rice | Meals | 70 | Yes |
| 8 | Sambar Rice | Meals | 75 | Yes |
| 9 | Lemon Rice | Meals | 65 | Yes |
| 10 | Veg Fried Rice | Meals | 120 | Yes |
| 11 | Egg Fried Rice | Meals | 130 | No |
| 12 | Chapati Kurma | Meals | 95 | Yes |
| 13 | Veg Thali | Meals | 150 | Yes |
| 14 | Chicken Curry Meal | Meals | 210 | No |
| 15 | Rava Upma | Meals | 44 | Yes |
| 16 | Samosa (2 pcs) | Snacks | 30 | Yes |
| 17 | Veg Puff | Snacks | 25 | Yes |
| 18 | Vada Pav | Snacks | 35 | Yes |
| 19 | French Fries | Snacks | 80 | Yes |
| 20 | Veg Sandwich | Snacks | 50 | Yes |
| 21 | Grilled Cheese Sandwich | Snacks | 90 | Yes |
| 22 | Veg Burger | Snacks | 100 | Yes |
| 23 | Chicken Burger | Snacks | 125 | No |
| 24 | Masala Maggi | Snacks | 58 | Yes |
| 25 | Pav Bhaji | Snacks | 110 | Yes |
| 26 | Bread Omelette | Snacks | 48 | No |
| 27 | Paneer Roll | Snacks | 105 | Yes |
| 28 | Chicken Roll | Snacks | 115 | No |
| 29 | Mini Pizza | Snacks | 135 | Yes |
| 30 | Bhel Puri | Snacks | 40 | Yes |
| 31 | Filter Coffee | Drinks | 20 | Yes |
| 32 | Masala Chai | Drinks | 15 | Yes |
| 33 | Cold Coffee | Drinks | 68 | Yes |
| 34 | Fresh Lime Soda | Drinks | 38 | Yes |
| 35 | Mango Lassi | Drinks | 72 | Yes |
| 36 | Buttermilk | Drinks | 18 | Yes |
| 37 | Watermelon Juice | Drinks | 52 | Yes |
| 38 | Orange Juice | Drinks | 62 | Yes |
| 39 | Banana Shake | Drinks | 78 | Yes |
| 40 | Chocolate Milkshake | Drinks | 88 | Yes |
| 41 | Bottled Water | Drinks | 10 | Yes |
| 42 | Tender Coconut | Drinks | 42 | Yes |
| 43 | Gulab Jamun (2 pcs) | Desserts | 45 | Yes |
| 44 | Chocolate Brownie | Desserts | 99 | Yes |
| 45 | Vanilla Ice Cream Cup | Desserts | 56 | Yes |
| 46 | Rasmalai | Desserts | 82 | Yes |
| 47 | Fruit Salad | Desserts | 66 | Yes |
| 48 | Kesari Bath | Desserts | 34 | Yes |
| 49 | Chocolate Cake Slice | Desserts | 92 | Yes |
| 50 | Payasam | Desserts | 54 | Yes |

Each item needs a short one-line description and an image. If real food photos are not available, use neat, consistent placeholders (never broken image links).

## 8. UX, accessibility and responsiveness

- **Mobile:** two-column card grid, full-width forms, 44px minimum tap targets, no horizontal overflow, and the floating bottom nav.
- **Tablet and desktop:** 3–4 column grid, a centered content width, and a cart page with a main column plus a sticky Order Summary. The bottom nav becomes a top bar or side nav on large screens.
- Show feedback after every action (item added, order placed, status changed) with toasts or inline messages.
- Include empty states (empty cart, no search results, no orders) and clear error messages that say what to do next.
- Use semantic HTML, labeled inputs, visible keyboard focus, accessible names on icon-only buttons, and readable contrast. Respect `prefers-reduced-motion`.
- Format all prices consistently as `₹1,234`.

## 9. Step-by-step build order

1. Choose and document the libraries (HTTP server, SQLite, cJSON, libsodium). Create the project skeleton and Makefile.
2. Write `db.c` with schema creation and `seed.c` with the two users and 50 menu items.
3. Implement `auth.c` and `session.c` (login, hashed token, 20-day cookie, `/api/me`, logout) and test persistence across a server restart.
4. Implement the menu API (read, search, filter), then shopkeeper CRUD and availability.
5. Implement `/api/checkout` as a single transaction with all the rules in Section 5.
6. Implement the orders API (user's own orders, shopkeeper's all orders, status update).
7. Build the frontend: login, user home, cart and checkout, order confirmation, My Orders, then the shopkeeper screens. Apply the visual system from Section 3.
8. Make it responsive, accessible and polished.
9. Test the full journey and the edge cases in Section 10.
10. Write the README and hand off.

## 10. Tests you must run

- Login as the user and as the shopkeeper. Verify wrong passwords fail and each role is blocked from the other's pages and APIs.
- Close and reopen the browser, and restart the server. Verify the login persists. Manually expire a session in the database and verify it forces re-login.
- Add items, change quantities, remove items, and verify the totals.
- Checkout with exactly enough balance, with too little balance, with an empty cart, with an out-of-stock item, with quantity 0 or negative, and with a double-click on Checkout.
- Verify the wallet balance is correct after several orders and never goes negative.
- Verify the shopkeeper sees the new bill, can mark it Finished and back to Pending, and that the user sees the updated status.
- Verify that editing an item's price does not change past bills.
- Verify SQL-injection-style inputs in the login and search fields are handled safely.

## 11. Rules for you, the AI developer

- Do not leave dead buttons, placeholder links or fake features.
- Do not store plaintext passwords or session tokens.
- Do not trust any total, price or role value sent from the browser.
- Keep the C code modular, with header files, brief comments on the important business rules, and error handling on every database and memory operation (free what you allocate).
- If something in this brief is impossible in the chosen setup, explain the limitation and offer the simplest honest alternative.

## 12. Final deliverable

Provide:
1. The complete source code in the layout above.
2. A `README.md` with install steps for the libraries, the build command (`make`), how to run the server, the URL to open, the demo credentials, and a short explanation of the architecture.
3. A short note on which parts are written in C, to help with the course presentation.
