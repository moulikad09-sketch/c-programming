#pragma once
#include <stdbool.h>

// Initialise the SQLite database (create file and schema if missing).
// Returns true on success, false on failure.
bool db_init(void);

