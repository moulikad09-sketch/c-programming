#include <stdio.h>
#include <sqlite3.h>
#include "db.h"

static const char *schema_sql = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT CHECK(role IN ('user','shopkeeper')) NOT NULL,
    display_name TEXT,
    wallet_balance REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    token_hash TEXT UNIQUE NOT NULL,
    user_id INTEGER REFERENCES users(id),
    created_at INTEGER,
    expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT,
    price REAL CHECK(price >= 0),
    is_veg INTEGER,
    image TEXT,
    available INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_number TEXT UNIQUE NOT NULL,
    user_id INTEGER REFERENCES users(id),
    total REAL,
    payment_method TEXT DEFAULT 'Wallet',
    status TEXT CHECK(status IN ('Pending','Finished')) DEFAULT 'Pending',
    created_at INTEGER,
    finished_at INTEGER
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER REFERENCES orders(id),
    menu_item_id INTEGER REFERENCES menu_items(id),
    name_snapshot TEXT,
    unit_price_snapshot REAL,
    quantity INTEGER CHECK(quantity > 0)
);
""";

bool db_init(void) {
    sqlite3 *db = NULL;
    int rc = sqlite3_open("data/canteen.db", &db);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        return false;
    }
    char *errmsg = NULL;
    rc = sqlite3_exec(db, schema_sql, NULL, NULL, &errmsg);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "SQL error: %s\n", errmsg);
        sqlite3_free(errmsg);
        sqlite3_close(db);
        return false;
    }
    sqlite3_close(db);
    return true;
}

