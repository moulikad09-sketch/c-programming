#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "db.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "sqlite3.lib")

#define PORT "8080"
#define BACKLOG 10
#define BUFFER_SIZE 8192

void send_response(SOCKET client, const char *status, const char *content_type, const char *body) {
    char header[1024];
    sprintf(header,
            "HTTP/1.1 %s\r\n"
            "Content-Type: %s\r\n"
            "Content-Length: %zu\r\n"
            "Connection: close\r\n"
            "\r\n",
            status, content_type, strlen(body));
    send(client, header, (int)strlen(header), 0);
    send(client, body, (int)strlen(body), 0);
}

void handle_client(SOCKET client) {
    char buffer[BUFFER_SIZE];
    int received = recv(client, buffer, BUFFER_SIZE - 1, 0);
    if (received <= 0) { closesocket(client); return; }
    buffer[received] = '\0';
    // Very naive request line parsing
    char method[8]; char path[256];
    if (sscanf(buffer, "%7s %255s", method, path) != 2) {
        closesocket(client); return;
    }
    // Health endpoint
    if (strcmp(path, "/api/health") == 0) {
        const char *json = "{\"status\": \"ok\"}";
        send_response(client, "200 OK", "application/json", json);
        closesocket(client);
        return;
    }
    // Serve static files from web/ (default to index.html)
    if (strcmp(path, "/") == 0) strcpy(path, "/index.html");
    // Build file path
    char file_path[512];
    snprintf(file_path, sizeof(file_path), "web%s", path);
    FILE *fp = fopen(file_path, "rb");
    if (!fp) {
        const char *notfound = "<h1>404 Not Found</h1>";
        send_response(client, "404 Not Found", "text/html", notfound);
        closesocket(client);
        return;
    }
    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *content = malloc(fsize + 1);
    fread(content, 1, fsize, fp);
    content[fsize] = '\0';
    const char *ctype = "text/html";
    // Very simple MIME detection based on extension
    const char *ext = strrchr(file_path, '.');
    if (ext) {
        if (strcmp(ext, ".css") == 0) ctype = "text/css";
        else if (strcmp(ext, ".js") == 0) ctype = "application/javascript";
        else if (strcmp(ext, ".json") == 0) ctype = "application/json";
        else if (strcmp(ext, ".png") == 0) ctype = "image/png";
        else if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0) ctype = "image/jpeg";
    }
    send_response(client, "200 OK", ctype, content);
    free(content);
    fclose(fp);
    closesocket(client);
}

int main() {
    printf("Starting Canteen Cart server on http://localhost:%s\n", PORT);
    // Initialise DB (creates schema if needed)
    if (!db_init()) {
        fprintf(stderr, "Failed to initialise database\n");
        return 1;
    }

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed\n");
        return 1;
    }
    struct addrinfo hints = {0}, *res;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    if (getaddrinfo(NULL, PORT, &hints, &res) != 0) {
        fprintf(stderr, "getaddrinfo failed\n");
        return 1;
    }
    SOCKET listen_sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (listen_sock == INVALID_SOCKET) {
        fprintf(stderr, "socket creation failed\n");
        return 1;
    }
    int opt = 1;
    setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));
    if (bind(listen_sock, res->ai_addr, (int)res->ai_addrlen) == SOCKET_ERROR) {
        fprintf(stderr, "bind failed\n");
        return 1;
    }
    freeaddrinfo(res);
    if (listen(listen_sock, BACKLOG) == SOCKET_ERROR) {
        fprintf(stderr, "listen failed\n");
        return 1;
    }
    while (1) {
        SOCKET client = accept(listen_sock, NULL, NULL);
        if (client == INVALID_SOCKET) continue;
        // Simple sequential handling (good enough for dev)
        handle_client(client);
    }
    closesocket(listen_sock);
    WSACleanup();
    return 0;
}

